

import UIKit

class detailViewController: UIViewController {
    
    var memeds: Meme!
    
    @IBOutlet weak var imageDeteil: UIImageView!
    

    override func viewWillAppear(_ animated: Bool) {
        imageDeteil.image = memeds.memedImage
    }
    
    
}
