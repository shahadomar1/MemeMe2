//
//  CollectionViewCell.swift
//  MemeMe
//
//  Created by shaden on ٢٥ ربيع١، ١٤٤٠ هـ.
//  Copyright © ١٤٤٠ هـ shaden. All rights reserved.
//

import UIKit

class CollectionViewCell: UICollectionViewCell {
    
    
        @IBOutlet weak var memedimageView: UIImageView!

    }
